export class ModelSucursal{
    Id?: string;
    Departamento?: string;
    Ciudad?: string;
    Direccion?: string;
    Telefono?: string;
}