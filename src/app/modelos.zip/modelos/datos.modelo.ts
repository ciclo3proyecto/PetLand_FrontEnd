export class ModeloDatos{
    id?: string;
    nombre?: string;
    correo?: string;
    rol?: string;

}