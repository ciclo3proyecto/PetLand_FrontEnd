import { ModeloDatos } from "./datos.modelo";

export class ModeloIdentificacion{
    
    datos?: ModeloDatos;
    tk?: string;
    estaIdentificado: boolean = false; 
}